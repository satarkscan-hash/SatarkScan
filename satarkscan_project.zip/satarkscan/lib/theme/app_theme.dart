import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ── Colors ──
  static const Color bgDark       = Color(0xFF07080F);
  static const Color bgCard       = Color(0xFF0F1420);
  static const Color bgCard2      = Color(0xFF131828);
  static const Color gold         = Color(0xFFC9A84C);
  static const Color goldLight    = Color(0xFFE8C96A);
  static const Color goldDim      = Color(0xFF7A6530);
  static const Color danger       = Color(0xFFFF4444);
  static const Color warning      = Color(0xFFF0B429);
  static const Color safe         = Color(0xFF2ECC71);
  static const Color textPrimary  = Color(0xFFFFFFFF);
  static const Color textSecondary= Color(0xFF8A8FA8);
  static const Color borderGold   = Color(0x33C9A84C);
  static const Color borderDim    = Color(0x18FFFFFF);

  static ThemeData get darkTheme => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgDark,
    primaryColor: gold,
    colorScheme: const ColorScheme.dark(
      primary: gold,
      secondary: goldLight,
      surface: bgCard,
      error: danger,
    ),
    textTheme: GoogleFonts.rajdhaniTextTheme(
      const TextTheme(
        displayLarge: TextStyle(color: textPrimary, fontWeight: FontWeight.w700),
        titleLarge:   TextStyle(color: textPrimary, fontWeight: FontWeight.w700),
        bodyMedium:   TextStyle(color: textSecondary),
      ),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: bgDark,
      elevation: 0,
      iconTheme: IconThemeData(color: textPrimary),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF0A0B10),
      selectedItemColor: gold,
      unselectedItemColor: Color(0xFF4A4D5A),
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: gold,
        foregroundColor: bgDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(vertical: 16),
        textStyle: GoogleFonts.orbitron(fontWeight: FontWeight.w700, fontSize: 13, letterSpacing: 2),
      ),
    ),
  );
}
