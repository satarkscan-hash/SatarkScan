enum RiskLevel { low, medium, high }
enum FindingSeverity { ok, warning, danger }

class ScanFinding {
  final FindingSeverity severity;
  final String message;
  const ScanFinding({required this.severity, required this.message});
}

class ScanResult {
  final RiskLevel riskLevel;
  final int score; // 0-100
  final String scannedValue;
  final List<ScanFinding> findings;
  final String scanType;
  final DateTime timestamp;

  const ScanResult({
    required this.riskLevel,
    required this.score,
    required this.scannedValue,
    required this.findings,
    required this.scanType,
    required this.timestamp,
  });

  // Mock result for testing
  static ScanResult mockHigh(String value) => ScanResult(
    riskLevel: RiskLevel.high,
    score: 82,
    scannedValue: value,
    scanType: 'Link',
    timestamp: DateTime.now(),
    findings: const [
      ScanFinding(severity: FindingSeverity.danger, message: 'Domain sirf 23 din purana hai — naya aur suspicious'),
      ScanFinding(severity: FindingSeverity.danger, message: 'Scam database mein 14 baar report hua hai'),
      ScanFinding(severity: FindingSeverity.warning, message: 'Keywords: "instant loan", "processing fee" detected'),
      ScanFinding(severity: FindingSeverity.ok, message: 'SSL certificate present hai'),
    ],
  );

  static ScanResult mockSafe(String value) => ScanResult(
    riskLevel: RiskLevel.low,
    score: 8,
    scannedValue: value,
    scanType: 'Link',
    timestamp: DateTime.now(),
    findings: const [
      ScanFinding(severity: FindingSeverity.ok, message: 'Domain 5 saal purana hai — trustworthy'),
      ScanFinding(severity: FindingSeverity.ok, message: 'Koi scam report nahi mila'),
      ScanFinding(severity: FindingSeverity.ok, message: 'SSL certificate valid hai'),
      ScanFinding(severity: FindingSeverity.ok, message: 'Koi suspicious keyword nahi mila'),
    ],
  );
}
