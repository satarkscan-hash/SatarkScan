import 'package:flutter/foundation.dart';

class AuthService extends ChangeNotifier {
  bool _isLoggedIn = false;
  String? _phone;

  bool get isLoggedIn => _isLoggedIn;
  String? get phone => _phone;

  Future<void> sendOtp(String phone) async {
    // TODO: Firebase Phone Auth
    await Future.delayed(const Duration(seconds: 1));
  }

  Future<bool> verifyOtp(String otp) async {
    // TODO: Firebase OTP verify
    await Future.delayed(const Duration(seconds: 1));
    _isLoggedIn = true;
    _phone = phone;
    notifyListeners();
    return true;
  }

  void logout() {
    _isLoggedIn = false;
    _phone = null;
    notifyListeners();
  }
}
