import 'package:flutter/foundation.dart';
import '../models/scan_result.dart';

class ScanService extends ChangeNotifier {

  // ── Link Scanner ──
  Future<ScanResult> scanLink(String url) async {
    await Future.delayed(const Duration(seconds: 2)); // Simulate API call

    // TODO: Replace with real API calls:
    // 1. Google Safe Browsing API
    // 2. WhoisXML Domain Age API
    // 3. Your Firebase Firestore scam database

    final suspicious = url.contains('loan') || url.contains('free') ||
        url.contains('win') || url.contains('otp') || !url.startsWith('https');

    return suspicious
        ? ScanResult.mockHigh(url)
        : ScanResult.mockSafe(url);
  }

  // ── Phone Checker ──
  Future<ScanResult> checkPhone(String phone) async {
    await Future.delayed(const Duration(seconds: 1));

    // TODO: Query Firestore 'ScamPhones' collection
    // db.collection('ScamPhones').where('number', isEqualTo: phone).get()

    return ScanResult(
      riskLevel: RiskLevel.high,
      score: 90,
      scannedValue: phone,
      scanType: 'Phone',
      timestamp: DateTime.now(),
      findings: const [
        ScanFinding(severity: FindingSeverity.danger, message: '12 users ne yeh number report kiya hai'),
        ScanFinding(severity: FindingSeverity.danger, message: 'Category: Loan Scam'),
        ScanFinding(severity: FindingSeverity.warning, message: 'Last report: 2 days ago'),
      ],
    );
  }

  // ── UPI Checker ──
  Future<ScanResult> checkUpi(String upiId) async {
    await Future.delayed(const Duration(seconds: 1));

    // TODO: Query Firestore 'ScamUPI' collection

    final risky = upiId.contains('loan') || upiId.contains('free');
    return risky
        ? ScanResult.mockHigh(upiId)
        : ScanResult.mockSafe(upiId);
  }

  // ── Screenshot Scanner (OCR) ──
  Future<ScanResult> scanScreenshot(String extractedText) async {
    await Future.delayed(const Duration(seconds: 2));

    // TODO: Use Google ML Kit to extract text, then check for keywords
    const scamKeywords = [
      'processing fee', 'instant loan', 'urgent payment',
      'otp share', 'account block', 'kyc update', 'prize won',
      'click here', 'limited offer', 'verify now',
    ];

    final lowerText = extractedText.toLowerCase();
    final matchedKeywords = scamKeywords.where((k) => lowerText.contains(k)).toList();

    final score = (matchedKeywords.length * 20).clamp(0, 100);
    final level = score >= 60 ? RiskLevel.high : score >= 30 ? RiskLevel.medium : RiskLevel.low;

    return ScanResult(
      riskLevel: level,
      score: score,
      scannedValue: 'Screenshot',
      scanType: 'Screenshot',
      timestamp: DateTime.now(),
      findings: [
        if (matchedKeywords.isNotEmpty)
          ScanFinding(severity: FindingSeverity.danger,
              message: 'Scam keywords found: ${matchedKeywords.join(", ")}')
        else
          const ScanFinding(severity: FindingSeverity.ok, message: 'Koi suspicious keyword nahi mila'),
      ],
    );
  }
}
