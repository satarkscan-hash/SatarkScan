import 'package:flutter/foundation.dart';

class ScamAlert {
  final String title;
  final String description;
  final String time;
  final int reports;
  final bool isDanger;
  const ScamAlert({required this.title, required this.description, required this.time, required this.reports, required this.isDanger});
}

class AlertService extends ChangeNotifier {
  List<ScamAlert> get alerts => const [
    ScamAlert(title: 'Fake Loan App – Delhi', description: 'Nayi fake loan app report ki gayi. Install mat karo.', time: '2 hours ago', reports: 47, isDanger: true),
    ScamAlert(title: 'OTP Scam – Mumbai', description: '+91-98765XXXXX se OTP maang rahe hain.', time: '5 hours ago', reports: 23, isDanger: false),
    ScamAlert(title: 'Fake Job Offer – Bangalore', description: 'IT company ke naam pe fake interview call aa rahi hai.', time: '1 day ago', reports: 31, isDanger: true),
    ScamAlert(title: 'Investment Scam – Pan India', description: 'WhatsApp group mein 10x return ka jhansa.', time: '2 days ago', reports: 89, isDanger: false),
  ];
}
