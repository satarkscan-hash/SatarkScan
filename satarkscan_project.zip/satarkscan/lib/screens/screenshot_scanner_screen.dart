// screenshot_scanner_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_button.dart';
import '../services/scan_service.dart';
import 'scan_result_screen.dart';

class ScreenshotScannerScreen extends StatefulWidget {
  const ScreenshotScannerScreen({super.key});
  @override
  State<ScreenshotScannerScreen> createState() => _ScreenshotScannerScreenState();
}
class _ScreenshotScannerScreenState extends State<ScreenshotScannerScreen> {
  XFile? _image;
  bool _loading = false;
  final _picker = ImagePicker();

  Future<void> _pick() async {
    final img = await _picker.pickImage(source: ImageSource.gallery);
    if (img != null) setState(() => _image = img);
  }
  Future<void> _scan() async {
    if (_image == null) return;
    setState(() => _loading = true);
    // TODO: Run Google ML Kit OCR on _image, then pass extracted text
    final result = await ScanService().scanScreenshot('processing fee instant loan OTP share');
    setState(() => _loading = false);
    if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ScanResultScreen(result: result, scanType: 'Screenshot')));
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    appBar: AppBar(title: Text('Screenshot Scanner', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
      leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context))),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      const SizedBox(height: 16),
      GestureDetector(
        onTap: _pick,
        child: Container(
          width: double.infinity, height: 200,
          decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: _image != null ? AppTheme.gold : AppTheme.borderGold, style: BorderStyle.solid)),
          child: _image == null
            ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.upload_file, color: AppTheme.gold, size: 48),
                const SizedBox(height: 12),
                Text('Screenshot upload karo', style: TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
                Text('WhatsApp / SMS / Email', style: TextStyle(color: Colors.white30, fontSize: 12)),
              ])
            : ClipRRect(borderRadius: BorderRadius.circular(16),
                child: Image.network(_image!.path, fit: BoxFit.cover)),
        ),
      ),
      const SizedBox(height: 24),
      Text('System screenshot mein se text nikal kar scam keywords dhundhega.',
          style: TextStyle(color: AppTheme.textSecondary, fontSize: 13), textAlign: TextAlign.center),
      const SizedBox(height: 32),
      GoldButton(label: '📸 SCAN SCREENSHOT', onTap: _image != null ? _scan : _pick, isLoading: _loading),
    ])),
  );
}
