// report_scam_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_button.dart';

class ReportScamScreen extends StatefulWidget {
  const ReportScamScreen({super.key});
  @override
  State<ReportScamScreen> createState() => _ReportScamScreenState();
}
class _ReportScamScreenState extends State<ReportScamScreen> {
  String _selectedType = 'Loan Scam';
  final _phoneCtrl = TextEditingController();
  final _linkCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  bool _loading = false;

  final List<String> _scamTypes = ['Loan Scam', 'Job Scam', 'Investment Scam', 'OTP Scam', 'Lottery Scam', 'Other'];

  Future<void> _submit() async {
    setState(() => _loading = true);
    await Future.delayed(const Duration(seconds: 1));
    // TODO: Save to Firestore 'ScamReports' collection
    setState(() => _loading = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Report submit ho gaya! Shukriya 🙏'), backgroundColor: AppTheme.safe));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    appBar: AppBar(title: Text('Report Scam', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
      leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context))),
    body: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _label('Scam Type'),
      Wrap(spacing: 8, runSpacing: 8, children: _scamTypes.map((t) => GestureDetector(
        onTap: () => setState(() => _selectedType = t),
        child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: _selectedType == t ? AppTheme.gold.withOpacity(0.15) : AppTheme.bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _selectedType == t ? AppTheme.gold : AppTheme.borderDim)),
          child: Text(t, style: TextStyle(color: _selectedType == t ? AppTheme.gold : AppTheme.textSecondary, fontSize: 12, fontWeight: FontWeight.w600))),
      )).toList()),
      const SizedBox(height: 20),
      _label('Phone Number (optional)'),
      _inputField(_phoneCtrl, '+91 98765 43210', TextInputType.phone),
      const SizedBox(height: 16),
      _label('Website Link (optional)'),
      _inputField(_linkCtrl, 'https://scam-site.com', TextInputType.url),
      const SizedBox(height: 16),
      _label('Description (optional)'),
      Container(decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGold)),
        child: TextField(controller: _descCtrl, maxLines: 4, style: const TextStyle(color: Colors.white, fontSize: 13),
          decoration: const InputDecoration(border: InputBorder.none, hintText: 'Kya hua batao...', hintStyle: TextStyle(color: Colors.white24), contentPadding: EdgeInsets.all(14)))),
      const SizedBox(height: 32),
      GoldButton(label: '🚨 SUBMIT REPORT', onTap: _submit, isLoading: _loading),
    ])),
  );

  Widget _label(String t) => Padding(padding: const EdgeInsets.only(bottom: 8),
    child: Text(t, style: TextStyle(color: AppTheme.gold.withOpacity(0.7), fontSize: 11, letterSpacing: 2)));

  Widget _inputField(TextEditingController c, String hint, TextInputType type) =>
    Container(decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGold)),
      child: TextField(controller: c, keyboardType: type, style: const TextStyle(color: Colors.white, fontSize: 13),
        decoration: InputDecoration(border: InputBorder.none, hintText: hint, hintStyle: const TextStyle(color: Colors.white24), contentPadding: const EdgeInsets.all(14))));
}
