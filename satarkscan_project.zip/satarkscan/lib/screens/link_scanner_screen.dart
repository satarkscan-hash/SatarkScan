import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_button.dart';
import '../services/scan_service.dart';
import 'scan_result_screen.dart';

class LinkScannerScreen extends StatefulWidget {
  const LinkScannerScreen({super.key});
  @override
  State<LinkScannerScreen> createState() => _LinkScannerScreenState();
}

class _LinkScannerScreenState extends State<LinkScannerScreen>
    with SingleTickerProviderStateMixin {
  final _urlCtrl = TextEditingController();
  bool _scanning = false;
  late AnimationController _spinCtrl;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
  }

  @override
  void dispose() { _spinCtrl.dispose(); _urlCtrl.dispose(); super.dispose(); }

  Future<void> _scan() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) { _showSnack('Link enter karo'); return; }
    setState(() => _scanning = true);
    final result = await ScanService().scanLink(url);
    setState(() => _scanning = false);
    if (mounted) {
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => ScanResultScreen(result: result, scanType: 'Link')));
    }
  }

  void _paste() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null) _urlCtrl.text = data!.text!;
  }

  void _showSnack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppTheme.bgCard));

  final List<String> _checks = [
    'Domain age verification',
    'SSL certificate check',
    'Scam database lookup',
    'Suspicious keyword scan',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Link Scanner', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
          Text('URL · Website · Domain', style: TextStyle(fontSize: 10, color: AppTheme.gold.withOpacity(0.6), letterSpacing: 1)),
        ]),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Scan ring
          Center(
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 20),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.borderGold),
              ),
              child: Column(children: [
                RotationTransition(
                  turns: _spinCtrl,
                  child: Container(
                    width: 90, height: 90,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppTheme.borderGold, width: 2),
                    ),
                    child: Container(
                      margin: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: AppTheme.borderGold),
                      ),
                      child: const Icon(Icons.link, color: AppTheme.gold, size: 32),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(_scanning ? 'SCANNING...' : 'READY TO SCAN',
                    style: TextStyle(color: Colors.white54, fontSize: 11, letterSpacing: 2)),
              ]),
            ),
          ),
          // Input
          Text('ENTER LINK', style: TextStyle(color: AppTheme.gold.withOpacity(0.7), fontSize: 11, letterSpacing: 2)),
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderGold),
            ),
            child: Row(children: [
              const SizedBox(width: 12),
              const Icon(Icons.link, color: Colors.white30, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _urlCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    hintText: 'https://example.com paste karo...',
                    hintStyle: TextStyle(color: Colors.white24, fontSize: 12),
                  ),
                ),
              ),
              GestureDetector(
                onTap: _paste,
                child: Container(
                  margin: const EdgeInsets.all(6),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(color: AppTheme.gold.withOpacity(0.12), borderRadius: BorderRadius.circular(6)),
                  child: Text('PASTE', style: TextStyle(color: AppTheme.gold, fontSize: 10, letterSpacing: 1)),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          // Chips
          Wrap(spacing: 8, children: [
            _chip('🌐 Website', true), _chip('📱 APK Link', false), _chip('📧 Email Link', false),
          ]),
          const SizedBox(height: 20),
          // Checks list
          Text('CHECKS PERFORMED', style: TextStyle(color: Colors.white30, fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 8),
          ..._checks.map((c) => Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: AppTheme.borderDim))),
            child: Row(children: [
              Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: AppTheme.gold.withOpacity(0.4))),
              const SizedBox(width: 12),
              Text(c, style: const TextStyle(color: Colors.white54, fontSize: 12)),
              const Spacer(),
              Text('READY', style: TextStyle(color: Colors.white24, fontSize: 9, letterSpacing: 1)),
            ]),
          )),
          const SizedBox(height: 24),
          GoldButton(label: '⚡ SCAN NOW', onTap: _scan, isLoading: _scanning),
          const SizedBox(height: 12),
          // Ad Banner
          Container(
            height: 52, decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppTheme.borderDim, style: BorderStyle.solid)),
            child: const Center(child: Text('AdMob Banner', style: TextStyle(color: Colors.white12, fontSize: 10, letterSpacing: 3))),
          ),
        ]),
      ),
    );
  }

  Widget _chip(String label, bool active) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: active ? AppTheme.gold.withOpacity(0.1) : Colors.white.withOpacity(0.04),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: active ? AppTheme.borderGold : AppTheme.borderDim),
    ),
    child: Text(label, style: TextStyle(color: active ? AppTheme.gold : Colors.white54, fontSize: 11, letterSpacing: 1)),
  );
}
