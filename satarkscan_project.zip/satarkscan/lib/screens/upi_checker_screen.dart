// upi_checker_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_button.dart';
import '../services/scan_service.dart';
import 'scan_result_screen.dart';

class UpiCheckerScreen extends StatefulWidget {
  const UpiCheckerScreen({super.key});
  @override
  State<UpiCheckerScreen> createState() => _UpiCheckerScreenState();
}
class _UpiCheckerScreenState extends State<UpiCheckerScreen> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  Future<void> _check() async {
    if (_ctrl.text.isEmpty) return;
    setState(() => _loading = true);
    final result = await ScanService().checkUpi(_ctrl.text);
    setState(() => _loading = false);
    if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ScanResultScreen(result: result, scanType: 'UPI')));
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    appBar: AppBar(title: Text('UPI Checker', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
      leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context))),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 20),
      Center(child: Container(width: 80, height: 80, decoration: BoxDecoration(shape: BoxShape.circle, color: AppTheme.bgCard, border: Border.all(color: AppTheme.borderGold)),
        child: const Icon(Icons.currency_rupee, color: AppTheme.gold, size: 36))),
      const SizedBox(height: 32),
      Text('UPI ID', style: TextStyle(color: AppTheme.gold.withOpacity(0.7), fontSize: 11, letterSpacing: 2)),
      const SizedBox(height: 6),
      Container(decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGold)),
        child: TextField(controller: _ctrl, style: const TextStyle(color: Colors.white, fontSize: 14),
          decoration: const InputDecoration(border: InputBorder.none, hintText: 'example@upi', hintStyle: TextStyle(color: Colors.white24), contentPadding: EdgeInsets.all(16)))),
      const SizedBox(height: 24),
      GoldButton(label: '💸 CHECK UPI', onTap: _check, isLoading: _loading),
    ])),
  );
}
