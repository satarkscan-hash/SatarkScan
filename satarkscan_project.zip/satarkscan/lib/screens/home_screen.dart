import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/scan_card.dart';
import '../widgets/alert_tile.dart';
import '../widgets/threat_meter.dart';
import 'link_scanner_screen.dart';
import 'phone_checker_screen.dart';
import 'upi_checker_screen.dart';
import 'screenshot_scanner_screen.dart';
import 'speed_tracker_screen.dart';
import 'report_scam_screen.dart';
import 'scam_alerts_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _navIndex = 0;

  final List<Map<String, dynamic>> _scanCards = [
    {'icon': Icons.link, 'title': 'Scan Link', 'sub': 'Website / URL check karo', 'color': AppTheme.gold},
    {'icon': Icons.screenshot_monitor, 'title': 'Scan Screenshot', 'sub': 'WhatsApp / SMS check', 'color': AppTheme.gold},
    {'icon': Icons.phone_android, 'title': 'Check Number', 'sub': 'Phone number verify karo', 'color': AppTheme.gold},
    {'icon': Icons.currency_rupee, 'title': 'Check UPI', 'sub': 'UPI ID safe hai ya nahi', 'color': AppTheme.gold},
  ];

  void _onCardTap(int index) {
    Widget screen;
    switch (index) {
      case 0: screen = const LinkScannerScreen(); break;
      case 1: screen = const ScreenshotScannerScreen(); break;
      case 2: screen = const PhoneCheckerScreen(); break;
      case 3: screen = const UpiCheckerScreen(); break;
      default: return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              // Ad Banner placeholder
              _adBanner(),
              const SizedBox(height: 4),
              _buildScanGrid(),
              // Speed Tracker full-width card
              _buildSpeedCard(),
              const SizedBox(height: 8),
              _buildAlertsSection(),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildHeader() => Container(
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
    decoration: BoxDecoration(
      color: AppTheme.bgCard,
      border: Border(bottom: BorderSide(color: AppTheme.borderGold)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: AppTheme.borderGold),
            color: const Color(0xFF1E2848),
          ),
          child: const Icon(Icons.shield_outlined, color: AppTheme.gold, size: 20),
        ),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          RichText(text: TextSpan(children: [
            TextSpan(text: 'Satark', style: GoogleFonts.orbitron(fontSize: 20, fontWeight: FontWeight.w900, color: AppTheme.gold)),
            TextSpan(text: 'Scan', style: GoogleFonts.orbitron(fontSize: 20, fontWeight: FontWeight.w700, color: Colors.white)),
          ])),
          Text('SCAN KARO · SATARK RAHO',
              style: TextStyle(fontSize: 9, letterSpacing: 2, color: AppTheme.gold.withOpacity(0.5))),
        ]),
        const Spacer(),
        IconButton(icon: const Icon(Icons.notifications_outlined, color: Colors.white54), onPressed: () {}),
      ]),
      const SizedBox(height: 12),
      const ThreatMeter(),
    ]),
  );

  Widget _adBanner() => Container(
    margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
    height: 52,
    decoration: BoxDecoration(
      color: AppTheme.bgCard,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: AppTheme.borderDim, style: BorderStyle.solid),
    ),
    child: Center(child: Text('AdMob Banner', style: TextStyle(color: Colors.white12, fontSize: 10, letterSpacing: 3))),
  );

  Widget _buildScanGrid() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
    child: GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: 4,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.3),
      itemBuilder: (_, i) => ScanCard(
        icon: _scanCards[i]['icon'],
        title: _scanCards[i]['title'],
        subtitle: _scanCards[i]['sub'],
        onTap: () => _onCardTap(i),
      ),
    ),
  );

  Widget _buildSpeedCard() => GestureDetector(
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SpeedTrackerScreen())),
    child: Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF131828), Color(0xFF0F1420)]),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderGold),
      ),
      child: Row(children: [
        const Icon(Icons.speed, color: AppTheme.gold, size: 26),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Speed Tracker', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
          Text('Internet speed test karo', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
        ]),
        const Spacer(),
        const Text('42 Mbps ↑', style: TextStyle(color: AppTheme.safe, fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(width: 6),
        const Icon(Icons.chevron_right, color: AppTheme.gold, size: 18),
      ]),
    ),
  );

  Widget _buildAlertsSection() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(children: [
        const Icon(Icons.warning_amber_rounded, color: AppTheme.warning, size: 18),
        const SizedBox(width: 6),
        Text('Latest Alerts', style: GoogleFonts.rajdhani(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 1)),
        const Spacer(),
        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ScamAlertsScreen())),
          child: Text('See all ›', style: TextStyle(color: AppTheme.gold, fontSize: 12)),
        ),
      ]),
    ),
    AlertTile(type: AlertType.danger, title: 'Fake Loan App – Delhi', desc: 'Nayi fake loan app report ki gayi. Install mat karo.', time: '2 hours ago', reports: 47),
    AlertTile(type: AlertType.warning, title: 'OTP Scam – Mumbai', desc: '+91-98765XXXXX se OTP maang rahe hain. Ignore karo.', time: '5 hours ago', reports: 23),
  ]);

  Widget _buildBottomNav() => BottomNavigationBar(
    currentIndex: _navIndex,
    onTap: (i) {
      if (i == 2) { Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportScamScreen())); return; }
      if (i == 1) { Navigator.push(context, MaterialPageRoute(builder: (_) => const ScamAlertsScreen())); return; }
      setState(() => _navIndex = i);
    },
    items: const [
      BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: 'Home'),
      BottomNavigationBarItem(icon: Icon(Icons.campaign_outlined), activeIcon: Icon(Icons.campaign), label: 'Alerts'),
      BottomNavigationBarItem(icon: Icon(Icons.report_outlined), activeIcon: Icon(Icons.report), label: 'Report'),
      BottomNavigationBarItem(icon: Icon(Icons.person_outline), activeIcon: Icon(Icons.person), label: 'Profile'),
    ],
  );
}
