// ── phone_checker_screen.dart ──
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_button.dart';
import '../services/scan_service.dart';
import 'scan_result_screen.dart';

class PhoneCheckerScreen extends StatefulWidget {
  const PhoneCheckerScreen({super.key});
  @override
  State<PhoneCheckerScreen> createState() => _PhoneCheckerScreenState();
}

class _PhoneCheckerScreenState extends State<PhoneCheckerScreen> {
  final _ctrl = TextEditingController();
  bool _loading = false;

  Future<void> _check() async {
    if (_ctrl.text.length < 10) return;
    setState(() => _loading = true);
    final result = await ScanService().checkPhone(_ctrl.text);
    setState(() => _loading = false);
    if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ScanResultScreen(result: result, scanType: 'Phone')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    appBar: AppBar(
      title: Text('Phone Checker', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
      leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context)),
    ),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 20),
        Center(child: Container(
          width: 80, height: 80,
          decoration: BoxDecoration(shape: BoxShape.circle, color: AppTheme.bgCard, border: Border.all(color: AppTheme.borderGold)),
          child: const Icon(Icons.phone_android, color: AppTheme.gold, size: 36),
        )),
        const SizedBox(height: 32),
        Text('PHONE NUMBER', style: TextStyle(color: AppTheme.gold.withOpacity(0.7), fontSize: 11, letterSpacing: 2)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGold)),
          child: Row(children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), decoration: BoxDecoration(border: Border(right: BorderSide(color: AppTheme.borderGold))),
              child: Text('+91', style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w700))),
            Expanded(child: TextField(
              controller: _ctrl, keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(10)],
              style: const TextStyle(color: Colors.white, fontSize: 16),
              decoration: const InputDecoration(border: InputBorder.none, hintText: '98765 43210', hintStyle: TextStyle(color: Colors.white24), contentPadding: EdgeInsets.symmetric(horizontal: 16)),
            )),
          ]),
        ),
        const SizedBox(height: 24),
        GoldButton(label: '🔍 CHECK NUMBER', onTap: _check, isLoading: _loading),
      ]),
    ),
  );
}
