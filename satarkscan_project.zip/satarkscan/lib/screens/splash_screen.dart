import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import 'otp_login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    _fadeAnim  = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.6, curve: Curves.easeOut)));
    _scaleAnim = Tween<double>(begin: 0.7, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.6, curve: Curves.elasticOut)));
    _ctrl.forward();

    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => const OtpLoginScreen()));
      }
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: Stack(
        children: [
          // Background glow
          Center(
            child: Container(
              width: 300, height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  AppTheme.gold.withOpacity(0.08),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
          // Content
          Center(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: ScaleTransition(
                scale: _scaleAnim,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Shield Icon
                    Container(
                      width: 100, height: 110,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppTheme.borderGold, width: 1),
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF1E2848), Color(0xFF0D1117)],
                        ),
                        boxShadow: [
                          BoxShadow(color: AppTheme.gold.withOpacity(0.3),
                              blurRadius: 30, spreadRadius: 5),
                        ],
                      ),
                      child: const Icon(Icons.shield_outlined,
                          color: AppTheme.gold, size: 52),
                    ),
                    const SizedBox(height: 24),
                    // Logo text
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(text: 'Satark',
                              style: GoogleFonts.orbitron(
                                  fontSize: 32, fontWeight: FontWeight.w900,
                                  color: AppTheme.gold,
                                  letterSpacing: 1)),
                          TextSpan(text: 'Scan',
                              style: GoogleFonts.orbitron(
                                  fontSize: 32, fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                  letterSpacing: 1)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text('SCAN KARO · SATARK RAHO',
                        style: GoogleFonts.rajdhani(
                            fontSize: 12, letterSpacing: 4,
                            color: AppTheme.gold.withOpacity(0.6),
                            fontWeight: FontWeight.w600)),
                    const SizedBox(height: 48),
                    SizedBox(
                      width: 40,
                      child: LinearProgressIndicator(
                        backgroundColor: AppTheme.borderGold,
                        valueColor: const AlwaysStoppedAnimation(AppTheme.gold),
                        minHeight: 2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Version
          Positioned(
            bottom: 32, left: 0, right: 0,
            child: Text('v1.0.0',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11,
                    color: Colors.white.withOpacity(0.2),
                    letterSpacing: 2)),
          ),
        ],
      ),
    );
  }
}
