// scam_alerts_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/alert_tile.dart';

class ScamAlertsScreen extends StatelessWidget {
  const ScamAlertsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    appBar: AppBar(title: Text('Scam Alerts', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
      leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context))),
    body: ListView(padding: const EdgeInsets.symmetric(vertical: 12), children: const [
      AlertTile(type: AlertType.danger, title: 'Fake Loan App – Delhi', desc: 'Nayi fake loan app report ki gayi. Install mat karo.', time: '2 hours ago', reports: 47),
      AlertTile(type: AlertType.warning, title: 'OTP Scam – Mumbai', desc: '+91-98765XXXXX se OTP maang rahe hain. Ignore karo.', time: '5 hours ago', reports: 23),
      AlertTile(type: AlertType.danger, title: 'Fake Job Offer – Bangalore', desc: 'IT company ke naam pe fake interview call aa rahi hai.', time: '1 day ago', reports: 31),
      AlertTile(type: AlertType.warning, title: 'Investment Scam – Pan India', desc: 'WhatsApp group mein 10x return ka jhansa diya ja raha hai.', time: '2 days ago', reports: 89),
      AlertTile(type: AlertType.danger, title: 'KYC Fraud – All Banks', desc: 'Bank ke naam pe link bhej kar KYC update maang rahe hain.', time: '3 days ago', reports: 156),
    ]),
  );
}

// speed_tracker_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_button.dart';

class SpeedTrackerScreen extends StatefulWidget {
  const SpeedTrackerScreen({super.key});
  @override
  State<SpeedTrackerScreen> createState() => _SpeedTrackerScreenState();
}
class _SpeedTrackerScreenState extends State<SpeedTrackerScreen> {
  bool _testing = false;
  double _download = 0, _upload = 0, _ping = 0;
  bool _done = false;

  Future<void> _runTest() async {
    setState(() { _testing = true; _done = false; _download = 0; _upload = 0; _ping = 0; });
    // Simulate speed test — replace with real speed test package
    for (int i = 1; i <= 10; i++) {
      await Future.delayed(const Duration(milliseconds: 300));
      setState(() { _download = i * 4.2; _upload = i * 2.1; _ping = 8.0 + i * 0.5; });
    }
    setState(() { _testing = false; _done = true; });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    appBar: AppBar(title: Text('Speed Tracker', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
      leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context))),
    body: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
      const SizedBox(height: 24),
      // Circular speed display
      Container(
        width: 180, height: 180,
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: RadialGradient(colors: [AppTheme.gold.withOpacity(0.1), Colors.transparent]),
          border: Border.all(color: AppTheme.borderGold, width: 2)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(_download.toStringAsFixed(1),
            style: GoogleFonts.orbitron(fontSize: 40, fontWeight: FontWeight.w900, color: AppTheme.gold)),
          Text('Mbps', style: TextStyle(color: AppTheme.textSecondary, fontSize: 14, letterSpacing: 2)),
          Text('DOWNLOAD', style: TextStyle(color: Colors.white30, fontSize: 10, letterSpacing: 2)),
        ]),
      ),
      const SizedBox(height: 32),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        _stat('📤 Upload', '${_upload.toStringAsFixed(1)} Mbps', AppTheme.safe),
        _stat('📡 Ping', '${_ping.toStringAsFixed(0)} ms', AppTheme.warning),
      ]),
      const SizedBox(height: 40),
      GoldButton(label: _testing ? 'TESTING...' : '⚡ START SPEED TEST', onTap: _testing ? () {} : _runTest, isLoading: _testing),
      if (_done) ...[
        const SizedBox(height: 16),
        Text('Test complete! ✅', style: TextStyle(color: AppTheme.safe, fontSize: 14, fontWeight: FontWeight.w700)),
      ],
    ])),
  );

  Widget _stat(String label, String value, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
    decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.borderGold)),
    child: Column(children: [
      Text(label, style: TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
      const SizedBox(height: 4),
      Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 16)),
    ]),
  );
}
