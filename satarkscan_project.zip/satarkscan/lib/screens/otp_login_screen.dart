import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_button.dart';
import 'home_screen.dart';

class OtpLoginScreen extends StatefulWidget {
  const OtpLoginScreen({super.key});
  @override
  State<OtpLoginScreen> createState() => _OtpLoginScreenState();
}

class _OtpLoginScreenState extends State<OtpLoginScreen> {
  final _phoneCtrl = TextEditingController();
  final List<TextEditingController> _otpCtrls =
      List.generate(6, (_) => TextEditingController());
  bool _otpSent = false;
  bool _loading = false;

  void _sendOtp() async {
    if (_phoneCtrl.text.length < 10) return;
    setState(() { _loading = true; });
    await Future.delayed(const Duration(seconds: 1)); // Firebase Auth here
    setState(() { _loading = false; _otpSent = true; });
  }

  void _verifyOtp() async {
    setState(() { _loading = true; });
    await Future.delayed(const Duration(seconds: 1));
    if (mounted) {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              // Logo
              Row(children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.borderGold),
                    color: const Color(0xFF1E2848),
                  ),
                  child: const Icon(Icons.shield_outlined, color: AppTheme.gold, size: 22),
                ),
                const SizedBox(width: 12),
                RichText(text: TextSpan(children: [
                  TextSpan(text: 'Satark', style: GoogleFonts.orbitron(fontSize: 22, fontWeight: FontWeight.w900, color: AppTheme.gold)),
                  TextSpan(text: 'Scan', style: GoogleFonts.orbitron(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white)),
                ])),
              ]),
              const SizedBox(height: 48),
              Text(!_otpSent ? 'Login / Sign Up' : 'Enter OTP',
                  style: GoogleFonts.orbitron(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white)),
              const SizedBox(height: 8),
              Text(!_otpSent
                  ? 'Apna mobile number enter karo'
                  : '+91 ${_phoneCtrl.text} pe OTP bheja gaya',
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
              const SizedBox(height: 36),

              if (!_otpSent) ...[
                // Phone input
                _label('Mobile Number'),
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.borderGold),
                  ),
                  child: Row(children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                      decoration: BoxDecoration(
                        border: Border(right: BorderSide(color: AppTheme.borderGold)),
                      ),
                      child: Text('+91', style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w700, fontSize: 15)),
                    ),
                    Expanded(
                      child: TextField(
                        controller: _phoneCtrl,
                        keyboardType: TextInputType.phone,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(10)],
                        style: const TextStyle(color: Colors.white, fontSize: 16),
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          hintText: '98765 43210',
                          hintStyle: TextStyle(color: Color(0xFF4A4D5A)),
                          contentPadding: EdgeInsets.symmetric(horizontal: 16),
                        ),
                      ),
                    ),
                  ]),
                ),
                const SizedBox(height: 32),
                GoldButton(label: 'SEND OTP', onTap: _sendOtp, isLoading: _loading),
              ] else ...[
                // OTP boxes
                _label('6-Digit OTP'),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(6, (i) => _otpBox(i)),
                ),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  TextButton(onPressed: () => setState(() => _otpSent = false),
                      child: Text('Number change karo', style: TextStyle(color: AppTheme.gold, fontSize: 13))),
                  TextButton(onPressed: _sendOtp,
                      child: Text('Resend OTP', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13))),
                ]),
                const SizedBox(height: 24),
                GoldButton(label: 'VERIFY & LOGIN', onTap: _verifyOtp, isLoading: _loading),
              ],
              const SizedBox(height: 48),
              Center(child: Text('By continuing, you agree to our Terms & Privacy Policy',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppTheme.textSecondary.withOpacity(0.5), fontSize: 11))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _label(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(text, style: TextStyle(color: AppTheme.gold.withOpacity(0.7),
        fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.w600)),
  );

  Widget _otpBox(int i) => SizedBox(
    width: 44, height: 52,
    child: TextField(
      controller: _otpCtrls[i],
      textAlign: TextAlign.center,
      keyboardType: TextInputType.number,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(1)],
      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700),
      decoration: InputDecoration(
        filled: true, fillColor: AppTheme.bgCard,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: AppTheme.borderGold)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: AppTheme.borderGold)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppTheme.gold, width: 1.5)),
      ),
      onChanged: (v) { if (v.isNotEmpty && i < 5) FocusScope.of(context).nextFocus(); },
    ),
  );
}
