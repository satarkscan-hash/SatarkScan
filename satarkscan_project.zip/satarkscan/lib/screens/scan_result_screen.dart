import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/scan_result.dart';
import 'report_scam_screen.dart';

class ScanResultScreen extends StatelessWidget {
  final ScanResult result;
  final String scanType;
  const ScanResultScreen({super.key, required this.result, required this.scanType});

  @override
  Widget build(BuildContext context) {
    final isHigh = result.riskLevel == RiskLevel.high;
    final isMed  = result.riskLevel == RiskLevel.medium;
    final color  = isHigh ? AppTheme.danger : isMed ? AppTheme.warning : AppTheme.safe;
    final label  = isHigh ? 'HIGH RISK' : isMed ? 'MEDIUM RISK' : 'LOW RISK';
    final icon   = isHigh ? '🚨' : isMed ? '⚠️' : '✅';
    final sub    = isHigh ? 'Scam detected · Do not trust'
                 : isMed  ? 'Suspicious · Be careful'
                 :           'Safe lagta hai';

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Scan Result', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.w700)),
          Text('Analysis Complete', style: TextStyle(fontSize: 10, color: AppTheme.gold.withOpacity(0.6), letterSpacing: 1)),
        ]),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.pop(context)),
        actions: [IconButton(icon: const Icon(Icons.share_outlined), onPressed: () {})],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Hero risk card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color.withOpacity(0.12), AppTheme.bgCard],
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Column(children: [
              Text(icon, style: const TextStyle(fontSize: 44)),
              const SizedBox(height: 8),
              Text(label, style: GoogleFonts.orbitron(fontSize: 24, fontWeight: FontWeight.w900, color: color,
                  shadows: [Shadow(color: color.withOpacity(0.4), blurRadius: 20)])),
              const SizedBox(height: 4),
              Text(sub, style: TextStyle(color: Colors.white54, fontSize: 12, letterSpacing: 2)),
              const SizedBox(height: 16),
              // Score bar
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: result.score / 100,
                  backgroundColor: Colors.white10,
                  valueColor: AlwaysStoppedAnimation(color),
                  minHeight: 8,
                ),
              ),
              const SizedBox(height: 6),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('Low', style: TextStyle(color: Colors.white24, fontSize: 10)),
                Text('Risk Score: ${result.score}/100', style: TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
                Text('High', style: TextStyle(color: Colors.white24, fontSize: 10)),
              ]),
            ]),
          ),
          const SizedBox(height: 16),
          // Scanned value
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.borderDim)),
            child: Row(children: [
              Icon(Icons.link, color: Colors.white38, size: 16),
              const SizedBox(width: 8),
              Expanded(child: Text(result.scannedValue,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'monospace'))),
              if (isHigh) const Icon(Icons.warning_amber_rounded, color: AppTheme.warning, size: 18),
            ]),
          ),
          const SizedBox(height: 20),
          // Findings
          Text('FINDINGS', style: TextStyle(color: Colors.white30, fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          ...result.findings.map((f) => _findingTile(f)),
          const SizedBox(height: 20),
          // Actions
          Row(children: [
            Expanded(
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportScamScreen())),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: AppTheme.danger.withOpacity(0.1),
                    border: Border.all(color: AppTheme.danger.withOpacity(0.3)),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text('🚨 Report Scam', textAlign: TextAlign.center,
                      style: TextStyle(color: AppTheme.danger, fontWeight: FontWeight.w700, fontSize: 13)),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: AppTheme.gold.withOpacity(0.1),
                  border: Border.all(color: AppTheme.borderGold),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text('📤 Share Alert', textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w700, fontSize: 13)),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          // Ad Banner
          Container(height: 52, decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppTheme.borderDim, style: BorderStyle.solid)),
              child: const Center(child: Text('AdMob Banner', style: TextStyle(color: Colors.white12, fontSize: 10, letterSpacing: 3)))),
        ]),
      ),
    );
  }

  Widget _findingTile(ScanFinding f) {
    Color bg, border, badgeColor;
    String badgeText;
    switch (f.severity) {
      case FindingSeverity.danger:
        bg = AppTheme.danger.withOpacity(0.06); border = AppTheme.danger.withOpacity(0.15);
        badgeColor = AppTheme.danger; badgeText = 'DANGER'; break;
      case FindingSeverity.warning:
        bg = AppTheme.warning.withOpacity(0.06); border = AppTheme.warning.withOpacity(0.15);
        badgeColor = AppTheme.warning; badgeText = 'WARN'; break;
      default:
        bg = AppTheme.safe.withOpacity(0.04); border = AppTheme.safe.withOpacity(0.12);
        badgeColor = AppTheme.safe; badgeText = 'OK'; break;
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10), border: Border.all(color: border)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(color: badgeColor.withOpacity(0.2), borderRadius: BorderRadius.circular(4)),
          child: Text(badgeText, style: TextStyle(color: badgeColor, fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 1)),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(f.message, style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.4))),
      ]),
    );
  }
}
